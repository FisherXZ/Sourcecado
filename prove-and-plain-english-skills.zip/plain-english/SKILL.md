---
name: plain-english
description: >-
  Translate technical work — implementation plans, architecture decisions, code
  changes, research, incident write-ups — into a clear, honest explanation a
  non-technical product manager can fully understand and act on. Use this
  whenever the user asks to "explain this in plain English", "break this down",
  "PM summary", "explain simply", "non-technical version", "explain for a
  stakeholder/exec/CEO", "make this readable for non-engineers", or otherwise
  wants something technical re-told for a non-technical reader. Reach for it even
  when the user doesn't say "PM" — any request to de-jargon, summarize for
  leadership, or make engineering work legible to a business audience counts.
  Default reader is a non-technical PM; adapt if the user names a different
  audience.
---

# Plain English

## What this is for

Engineers and PMs fail each other in a predictable way: the engineer explains
*what* and *how* in the vocabulary of the system, and the PM walks away unsure
*why it matters* or *what they can now tell their stakeholders*. This skill
closes that gap. It takes technical material that's already in front of you — a
plan we just wrote, a diff, an architecture decision, a research doc — and
re-tells it so a smart, non-technical reader understands it completely and could
confidently explain it to someone else.

The goal is not "dumb it down." It's **faithful translation**: every claim stays
true, and an engineer reading over the PM's shoulder should nod, not wince.

## Where the input comes from

Work with **whatever is already in context** — the plan, doc, diff, or discussion
at hand. That's the common case ("explain what we just did"). If the user points
at a specific file or PR, use that instead. Don't make the user re-paste things
you can already see.

If the source is genuinely ambiguous (several candidate docs, nothing obviously
"the thing"), ask one short question to pin it down rather than guessing.

## The voice: plain and honest

This is the heart of the skill. Aim for the register of a thoughtful engineer
explaining their work to a colleague they respect who happens not to be
technical — the calm, concrete, no-hype style you see in good OpenAI/Anthropic
explanatory writing. Concretely:

- **Lead with what it is and why it matters**, in everyday words. A PM should get
  the gist from the first few sentences without decoding anything.
- **Use concrete analogies** where they earn their place ("a tripwire that blocks
  the change", "today's speed plus a little headroom"). Analogies illuminate; they
  don't replace the real thing.
- **No hype, no salesmanship.** Say what's true plainly. Confidence comes from
  clarity, not adjectives.
- **Define jargon inline the first time** it's unavoidable, then use the plain
  phrase. Don't make the reader hold a glossary in their head.
- **Be honest about limits.** A short "what this does *not* tell us / what it
  won't do" beat is often the most valuable part for a PM, because it stops them
  over-promising to *their* stakeholders. Include it whenever there are real
  caveats. This honesty is a signature of the style — don't skip it to look good.

## Stay simple *and* verifiable

A PM-friendly explanation that quietly becomes false is worse than useless — it
sends the PM to misinform someone else. So hold two things at once:

- **Plain phrase with the real term beside it.** Give the everyday wording *and*
  the actual technical name, so the PM and an engineer are provably talking about
  the same thing. For example: the read-your-data endpoints (`GET
  /api/core-api-requests`) — not just "the data pages", and not a wall of
  parentheses either. The plain phrase leads; the technical anchor rides alongside.
- **Show the evidence when a claim rests on engineering reality.** If you're
  asserting something a skeptical engineer would want to verify — "these endpoints
  never charge credits", "provider URLs are hardcoded" — cite the code that proves
  it (`file.ts:line`, or a short snippet). This is what makes the translation
  *trustworthy*, not just readable. A PM may skim past the citation; an engineer
  can check it. Both are served.
- **Flag uncertainty instead of guessing.** If you're not sure something is true,
  say so ("I haven't confirmed X") rather than asserting it cleanly. A confident
  falsehood is the one outcome this skill must never produce.

Where do citations come from? If the material in context already contains them
(like a plan that references `auth.service.ts:341`), carry them through. If a
load-bearing claim has no backing and you can quickly verify it by reading the
code, do — a real anchor beats a hand-wave. If you can't verify it, flag it.

## Structure: fit the material, don't force a template

There is **no fixed skeleton**. Different inputs want different shapes — a single
code change might be three sentences plus a caveat; a six-task plan wants a
walkthrough table; an architecture decision wants the tradeoff laid out. Choose
the shape that makes *this* material clearest.

A few reliable instincts (use when they fit, drop when they don't):

- Open with a one-paragraph version someone could read aloud in a standup.
- A step-by-step table earns its keep when explaining a multi-part plan.
- "What the business gets" / "what this won't give us" beats are valuable when
  there are outcomes and limits worth stating.
- Sequencing/dependencies matter when the PM needs to know what blocks what.

Let the content pick. Consistency of *voice* matters; rigidity of *layout* does not.

## Audience

Default to a **non-technical product manager**. If the user names a different
reader — "for our CEO", "for a customer", "for the support team" — adjust depth
and framing accordingly (an exec wants outcome and risk fast; a customer wants
what changes for them; keep the same honesty throughout). When no audience is
named, the PM default holds.

## Output flow

Render the explanation **in the conversation first**, so the user can read and
tweak it. Then **offer to save it** to a doc (suggest a sensible path like
`docs/<topic>-pm-summary.md`) rather than writing a file unasked — the user often
wants to adjust wording before it lands anywhere shareable.

## A worked feel (not a template)

Input (technical): "We set the `ensure` plugin threshold to baseline p95 × 1.15
so CI fails on regression."

Plain-English output: "We measure how fast we are today, then set the bar at
*today's speed plus a little headroom* (technically: 95th-percentile latency ×
1.15). From then on, if someone's change crosses that line, the build system
blocks it automatically — the same way a failing test would. **What it won't do:**
tell us our absolute ceiling under real production traffic; that needs a bigger
setup, which is a later phase."

Notice: plain lead, real term carried alongside, analogy that clarifies, and an
honest limit at the end. That's the target — applied flexibly, never as a fill-in
form.
